# TURD-like Spot Detector Streamlit App

This package contains a Streamlit application for detecting and measuring “TURD‑like” deposits in images.  The app wraps the Python code from the provided `Main.py` into a simple, cross‑platform bundle.  Once you install the Python dependencies listed in `requirements.txt`, you can run the app on Windows, macOS or Linux using Streamlit.

## Included files

- **`main.py`** — the Streamlit application source code (copied from your original `Main.py`).  Run this file with Streamlit to launch the app.
- **`requirements.txt`** — a list of Python packages required by the app.
- **`run_app.sh`** — a helper script for Unix/macOS systems to install dependencies and start the app.
- **`run_app.bat`** — a helper script for Windows systems to install dependencies and start the app.

## Installation & Usage

1. Ensure you have Python 3.8 or later installed.
2. Open a terminal (Command Prompt on Windows) and navigate to the extracted folder.
3. Install the dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Launch the Streamlit app:

   ```bash
   streamlit run main.py
   ```

Alternatively, you can use the provided helper scripts:

### Windows

Double‑click `run_app.bat` or run it from a command prompt.  The script installs the dependencies (if needed) and starts the app.

### macOS / Linux

Run the following command from a terminal:

```bash
chmod +x run_app.sh
./run_app.sh
```

The script installs the dependencies (if needed) and starts the app.

## Notes

- The app uses the `streamlit_drawable_canvas` component for drawing regions of interest (ROIs).  If you experience issues with this component, ensure that the package is installed correctly (see `requirements.txt`).
- When running the app in an isolated environment (e.g., a fresh machine), the first run may take a few minutes while Python packages are installed.