#!/bin/bash
# Helper script to run the TURD-like Spot Detector Streamlit app on Unix/macOS.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "Installing Python dependencies..."
python -m pip install --user --upgrade pip > /dev/null 2>&1 || true
python -m pip install --user -r requirements.txt

echo "Starting Streamlit app..."
exec python -m streamlit run main.py